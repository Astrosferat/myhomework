<p>
    Please Log in:
</p>
<form method="POST" action="modul/give_pass.php">
    <p>
        Username:
        <input type="text" name="username" />
    </p>
    <p>
        Password:
        <input type="password" name="password" />
    </p>
    <input type="submit" value="Log in" />
</form>
<h4>
    <p>
        We have such correct rules:
    </p> 
    <p>
        Username will be: Admiral, password: general
    </p> 
    <p>
        Username will be: Captain, password: midle
    </p>         	        	
    <p>
        Username will be: Boatswain, password: pilot
    </p>  
</h4>
