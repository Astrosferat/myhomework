<p>
    A beekeeper is a person who keeps honey bees (i.e. practices beekeeping).
</p>
<p>
    Honey bees produce commodities such as honey, beeswax, pollen, and royal jelly, while some beekeepers also raise queens and bees to sell to other farmers, and to satisfy scientific curiosity. Beekeepers also use honeybees to provide pollination services to fruit and vegetable growers. Many people keep bees as a hobby. Others do it for income, either as a sideline to other work, or as a commercial operator. These factors affect the number of colonies maintained by the beekeeper.</p>
</ul>
