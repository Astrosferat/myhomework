<p>
    Please chose a file
</p>
<p>
    <form action=index.php?page=upload method=post enctype=multipart/form-data>
        <input type=file name=uploadfile>
        <input type=submit value=Load>
    </form>
</p>
